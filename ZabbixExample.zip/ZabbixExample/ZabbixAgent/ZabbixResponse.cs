﻿namespace ZabbixAgent
{
    public class ZabbixResponse
    {
        public string Value { get; set; }
    }
}
