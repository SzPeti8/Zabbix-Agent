﻿namespace ZabbixAgent
{
    public class Agent : IAgent
    {
        public void Init(string servername, int port)
        {
            // TODO: konfig beállítások betöltése
        }

        public void Start()
        { }

        public void Stop()
        { }

        public void Process()
        {
            var rr = new ZAbbixRR()
            {
                Request = new ZabbixRequest()
                {
                    Hostname = "localhost",
                    Key = "system.uptime"
                }
            };
            RequestReceived?.Invoke(this, rr);

            Console.WriteLine(rr.Response.Value);
        }

        public event EventHandler<ZAbbixRR> RequestReceived;
    }
}
