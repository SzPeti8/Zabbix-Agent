﻿namespace ZabbixAgent
{
    public class Agent7 : IAgent
    {
        public event EventHandler<ZAbbixRR> RequestReceived;

        public void Init(string servername, int port)
        {
            throw new NotImplementedException();
        }

        public void Process()
        {
            throw new NotImplementedException();
        }

        public void Start()
        {
            throw new NotImplementedException();
        }

        public void Stop()
        {
            throw new NotImplementedException();
        }
    }
}
