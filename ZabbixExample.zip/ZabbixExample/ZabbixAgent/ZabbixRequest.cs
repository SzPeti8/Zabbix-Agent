﻿namespace ZabbixAgent
{
    public class ZabbixRequest
    {
        public string Hostname { get; set; }
        public string Key { get; set; }
    }
}
